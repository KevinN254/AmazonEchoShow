
var Alexa = require('alexa-sdk');
var request = require('request');

exports.handler = function(event, context, callback){
  var alexa = Alexa.handler(event, context);
  alexa.APP_ID = 'amzn1.ask.skill.716569c1-1d59-4ec7-b109-c4e713f76144';
  alexa.registerHandlers(handlers);
  alexa.TableName = "session";
  alexa.execute();

};

var handlers = {

  'LaunchRequest': function () {
    this.emit(':ask',"Hello welcome to Autotrader.");
    /*var message = "Hello welcome to Autotrader";
    var cardContent = "Let's find you a car";
    var imageObj = {
      smallImageUrl: "https://www.autotrader.com/resources/img/atcui/template/autotrader-logo-blue.png",
      largeImageUrl: "https://www.autotrader.com/resources/img/atcui/template/autotrader-logo-blue.png"
    };

    var cardTitle = 'Autotrader.com';
    this.emit(':askWithCard', message, cardTitle, cardContent, imageObj);  */
  },

  'getCarIntent': function() {
    // var make = this.event.request.intent.slots.make.id;
    var city = this.event.request.intent.slots.city.value;
    var makeCode = this.event.request.intent.slots.make.value;
    var makeName= this.event.request.intent.slots.make.value;
  

    // var year = this.event.request.intent.slots.year.value;
    // var model = this.event.request.intent.slots.model.value;
    // var city = this.event.request.intent.slots.city.value;
    // var state = this.event.request.intent.slots.state.value;
    // var endpoint = "https://mdotqa:bNV35gGvLlD2Y8D0YVke@api-qa-origin.autotrader.com/rest/v0/listings?makeCodeList="+ make;
    var endpoint = "https://www.autotrader.com/rest/searchresults/base?makeCodeList="+ makeCode.toUpperCase() + "&" + city +"&searchRadius=0" ;
    // var endpoint = "https://www.autotrader.com/rest/searchresults/base?" + city;
    
    console.log(endpoint);
    // https://www.autotrader.com/rest/searchresults/base?Alpharetta+GA&makeCodeList=CHEV&searchRadius=0

    //Issue a get request
    request.get(endpoint, (error, response, body) => {
        if (response.statusCode !== 200) {
            console.log("There was an error processing your request. Here\'s what happened: " +
            response.statusCode + " " + response.statusCode);
            console.log(error);          
        }
        else{
            //parse the data into the JSON body
            data=JSON.parse(body);
            console.log(body);
            // SimpleCar.
            var make = data.listings[0].makeCode;
            var price = data.listings[0].salePrice;
            var listingImage = data.listings[0].imageURL;
            
            // var model = data.listings.modelCode;
            // var price = data.listings.salePrice;

            // this.emit(':tell', "I found you a " + makeName + " priced at " + price + ". Would you like to see more?" );

            var message = "I found you a " + makeName + " priced at " + price + ". Would you like to see more?";
            var cardContent = make + " " + price;
            var imageObj = {
              smallImageUrl: listingImage,
              largeImageUrl: listingImage
            };

           var cardTitle = 'Autotrader.com';
            //this.emit(':tell',  message);
            this.emit(':tellWithCard', message, cardTitle, cardContent, imageObj);
        }
    });

    //display


  },

  'AMAZON.StopIntent': function () {
    // State Automatically Saved with :tell
    this.emit(':tell', `Goodbye.`);
  },
  'AMAZON.CancelIntent': function () {
    // State Automatically Saved with :tell
    this.emit(':tell', `Goodbye.`);
  },
  'SessionEndedRequest': function () {
    // Force State Save When User Times Out
    this.emit(':saveState', true);
  },

  'AMAZON.HelpIntent' : function () {
    this.emit(':ask', `You can tell me to find you a specific car in a specific city or near you . Where would you like me to find you a car?`);
  },
  'Unhandled' : function () {
    this.emit(':ask', `You can tell me to find you a specific car in a specific city or near you . Where would you like me to find you a car?`);
  }

};